<section class="themePanel">
        <h1>Choose Your Theme</h1>

        <div class="theme-box" data-theme="0">
            <div class="activeTheme">
                <img src="<?php echo e(asset('backend/assets/images/theme1.png')); ?>" alt="">
                <div class="colorCombo color1 d-flex justify-content-center">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>


            <h3>Theme1</h3>
        </div>
        <div class="theme-box" data-theme="1">
            <div>
                <img src="<?php echo e(asset('backend/assets/images/theme2.png')); ?>" alt="">
                <div class="colorCombo color2 d-flex justify-content-center">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
            <h3>Theme2</h3>
        </div>

    </section>
    <div class="overlay-close"></div><?php /**PATH C:\xampp\htdocs\test\resources\views/layouts/themepanel.blade.php ENDPATH**/ ?>